# prog4

shell files for the intro cg class's fourth programming assignment
